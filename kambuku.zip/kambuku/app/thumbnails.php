<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class thumbnails extends Model
{
    //
    protected $table = 'classified_thumbnails';
}
