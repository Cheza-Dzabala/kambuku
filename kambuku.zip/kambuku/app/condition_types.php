<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class condition_types extends Model
{
    //
    protected $table='condition_types';
}
