<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class permission_types extends Model
{
    //
    protected $table = 'permission_types';
}
