<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('admin/assets/datatables/jquery.dataTables.min.css" rel="stylesheet')); ?>" type="text/css" />
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
            <!-- ============================================================== -->
    <!-- Start right Content here -->
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <ul>
                        <li class="dropdown" style="list-style: none">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                           <span class="panel-title"><h4>Bad Word Filters
                                                   <span class="caret"></span></h4>
                                               </span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo e(route('admin.badwordsNew')); ?>">New Word Filter</a></li>
                            </ul>
                        </li>
                    </ul>


                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="table-responsive">
                                <table id="datatable" class="table table-striped table-bordered">
                                    <thead>
                                    <tr>

                                        <th>Filter Name</th>
                                        <th>Active Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php foreach($badwords as $word): ?>
                                        <tr>

                                            <td><?php echo e($word['filter_name']); ?></td>
                                            <td>
                                                <?php if($word['is_active'] == 1): ?>
                                                    <span class="text-success">Active</span>
                                                <?php else: ?>
                                                    <span class="text-danger">Inactive</span>
                                                <?php endif; ?>

                                            </td>

                                            <td>
                                                <div>
                                                    <a href="<?php echo e(route('admin.badwordsEdit', [$word->filter_name])); ?>">
                                                        Edit Word List
                                                    </a>
                                                    |
                                                      <a href="<?php echo e(url('admin/badwords/delete/'.$word->id)); ?>">
                                                      Delete
                                                    </a>

                                                </div>
                                            </td>

                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- ============================================================== -->
    <!-- End Right content here -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/assets/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/assets/datatables/dataTables.bootstrap.js')); ?>"></script>


    <script type="text/javascript">
        $(document).ready(function() {
            $('#datatable').dataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>