<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php echo $__env->yieldContent('title'); ?>| Kambuku</title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/prettyPhoto.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/price-range.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet">
    <!--Custom Scripts Noptification Plugin-->
    <link href="<?php echo e(asset('js/timepicker/bootstrap-timepicker.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('js/timepicker/bootstrap-datepicker.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('js/notifications/notification.css')); ?>" rel="stylesheet" />

    <!-- Custom Files -->

    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css" />

    <!--venobox lightbox-->
    <link rel="stylesheet" href="<?php echo e(asset('js/magnific-popup/magnific-popup.css')); ?>"/>
    <!--[if lt IE 9]-->
    <script src="<?php echo e(asset('js/html5shiv.js')); ?>"></script>
    <script src="<?php echo e(asset('js/respond.min.js')); ?>"></script>
    <![endif]-->
    <?php echo $__env->yieldContent('css'); ?>
    <link rel="shortcut icon" href="<?php echo e(asset('images/ico/favicon.ico')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(asset('images/ico/apple-touch-icon-144-precomposed.png')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo e(asset('images/ico/apple-touch-icon-114-precomposed.png')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo e(asset('images/ico/apple-touch-icon-72-precomposed.png')); ?>">
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('images/ico/apple-touch-icon-57-precomposed.png')); ?>">

</head><!--/head-->

<body>
<header id="header"><!--header-->
    <div class="header_top"><!--header_top-->
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="contactinfo">
                        <ul class="nav nav-pills">
                            <li><a href="#"><i class="fa fa-phone"></i> +265 99 91 88 821</a></li>
                            <li><a href="#"><i class="fa fa-envelope"></i> info@kambuku.com</a></li>
                            <li class="dropdown" style="cursor: pointer;">
                                <?php if(Config::get('app.locale')== 'en'): ?>
                                    <a class="dropdown-toggle" data-toggle="dropdown">
                                        <img src="<?php echo e(asset('images/flags/gb.png')); ?>" class="position-left" alt="">
                                        English
                                        <span class="caret"></span>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href="<?php echo e(route('language.set', 'mw')); ?>" class="chichewa" style="cursor: pointer;">
                                                <img src="<?php echo e(asset('images/flags/mw.png')); ?>" alt="">
                                                Chichewa
                                            </a>
                                        </li>
                                    </ul>
                                    <?php else: ?>
                                    <a class="dropdown-toggle" data-toggle="dropdown">
                                        <img src="<?php echo e(asset('images/flags/mw.png')); ?>" class="position-left" alt="">
                                        Chichewa
                                        <span class="caret"></span>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href="<?php echo e(route('language.set', 'en')); ?>" class="chichewa" style="cursor: pointer;">
                                                <img src="<?php echo e(asset('images/flags/gb.png')); ?>" alt="">
                                                English
                                            </a>
                                        </li>
                                    </ul>

                                <?php endif; ?>
                            </li>

                        </ul>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="social-icons pull-right">
                        <ul class="nav navbar-nav">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div><!--/header_top-->
<?php echo $__env->yieldContent('middle_header'); ?>
<?php echo $__env->yieldContent('bottom_header'); ?>
</header><!--/header-->

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->yieldContent('vue_templates'); ?>


<?php echo $__env->yieldContent('footer'); ?>


<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('js/links.js')); ?>"></script>
<script src="<?php echo e(asset('js/socket.io.js')); ?>"></script>
<script src="<?php echo e(asset('js/test.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.scrollUp.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/price-range.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.prettyPhoto.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<script src="<?php echo e(asset('js/timepicker/bootstrap-timepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/timepicker/bootstrap-datepicker.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/gallery/isotope.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/magnific-popup/magnific-popup.js')); ?>"></script>
<!-- NOTIFICATION -->
<script src="<?php echo e(asset('js/notifications/notify.js')); ?>"></script>
<script src="<?php echo e(asset('js/notifications/notify-metro.js')); ?>"></script>
<script src="<?php echo e(asset('js/notifications/notifications.js')); ?>"></script>
<script src="<?php echo e(asset('js/global.js')); ?>"></script>


<!-- Chat -->


<!-- Other -->
<script src="<?php echo e(asset('js/jquery.nicescroll.js')); ?>" type="text/javascript"></script>
<script>
    var socket = io(main_host+':3000');
   // var message_socket = io(main_host+'4000');
</script>
<?php echo $__env->yieldContent('scripts'); ?>

<script>
    // Date Picker
    jQuery('#datepicker').datepicker();
    jQuery('#datepicker-inline').datepicker();
    jQuery('#datepicker-multiple').datepicker({
        numberOfMonths: 3,
        showButtonPanel: true
    });






</script>

<?php echo $__env->yieldContent('jquery'); ?>

<?php if(Auth::check()): ?>
    <script>

        //Announce Online


        //Comment Sockets

        socket.on("comment-channel:App\\Events\\NewCommentEvent", function (message) {
            // alert('comment');
            if (message.data.human_target == "<?php echo e(Auth::user()->id); ?>") {
                //  var resizefunc = [];
                $.Notification.notify('info', 'top right', 'New Comment from ' + message.data.name + ' On Product ' + message.data.title, message.data.comment);
            }
        });


        //Messaging Sockets
        socket.on("message-channel:App\\Events\\NewMessage", function (message) {
            if (message.data.human_target == "<?php echo e(Auth::user()->id); ?>") {
                if (window.location.href == main_link + 'messaging') {
                    null;
                } else {
                    $.Notification.notify('success', 'top right', 'New Message from ' + message.data.sender_name, message.data.message_body);
                }
            }
        });

        //Online Users
        socket.on("online-channel:App\\Events\\ShoutEvent", function(message){

        });

    </script>
<?php endif; ?>
</body>
</html>