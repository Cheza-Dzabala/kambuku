<span><h2>Be Safe</h2></span>
<span style="visibility: hidden"><?php echo e($i = 1); ?></span>
<?php foreach($guidelines as $key => $value): ?>
    <div >
        <h4><?php echo e($i.'.'. $value['title']); ?></h4>
        <p><?php echo e($value['guide']); ?></p>
        <span style="visibility: hidden"><?php echo e($i++); ?></span>
    </div>
<?php endforeach; ?>