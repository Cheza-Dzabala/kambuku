<?php $__env->startSection('middle_header'); ?>
    <?php echo $__env->make('partials.middle_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="form" style="margin-top: 5px; margin-bottom: 5px"><!--form-->
        <div class="container" >
            <div class="row">
                <div class="col-sm-4 col-sm-offset-1">
                    <div class="signup-form"><!--sign up form-->
                        <h2>New User Signup!</h2>
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                            <?php echo csrf_field(); ?>


                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <div class="col-md-6">
                                    <input type="text"
                                           name="name"
                                           value="<?php echo e(old('name')); ?>"
                                           placeholder="Name"
                                           style="width: 300px"
                                    >

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <div class="col-md-6">
                                    <input type="email"
                                           name="email"
                                           value="<?php echo e(old('email')); ?>"
                                           placeholder="Email"
                                           style="width: 300px"
                                    >

                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group<?php echo e($errors->has('date_of_birth') ? ' has-error' : ''); ?>">
                                <div class="col-md-6">
                                    <input type="text"
                                           name="date_of_birth"
                                           style="width: 300px"
                                           placeholder="mm/dd/yyyy" id="datepicker"
                                    >
                                    <?php if($errors->has('date_of_birth')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('date_of_birth')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('gender') ? ' has-error' : ''); ?>">
                                <div class="col-md-6">
                                    <select name="gender" style="width: 300px">
                                        <option value="m">Male</option>
                                        <option value="f">Female</option>
                                    </select>
                                    <?php if($errors->has('gender')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('gender')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <div class="col-md-6">
                                    <input type="password"
                                           name="password"
                                           placeholder="Password"
                                           style="width: 300px"
                                    >
                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">

                                <div class="col-md-6">
                                    <input type="password"
                                           name="password_confirmation"
                                           placeholder="Confirm Password"
                                           style="width: 300px"
                                    >

                                    <?php if($errors->has('password_confirmation')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-btn fa-user"></i>Register
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
             </div>
         </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>