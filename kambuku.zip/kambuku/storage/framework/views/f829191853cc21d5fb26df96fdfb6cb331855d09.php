<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('admin/assets/datatables/jquery.dataTables.min.css" rel="stylesheet')); ?>" type="text/css" />
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
            <!-- ============================================================== -->
    <!-- Start right Content here -->
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">

                <div class="panel-heading">
                    <ul>
                        <li class="dropdown" style="list-style: none">
                            <span class="panel-title"><h4><?php echo e($listing->title); ?></h4><small>Viewed <?php echo e($listing->view_count); ?> times | Created On: <?php echo e($listing->created_at); ?></small></span>
                        </li>
                    </ul>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="row">
                            <div class="panel-heading">
                                <div class="panel-title">Listers Details</div>
                            </div>
                            <div class="panel-body">
                                Name: <?php echo e($user->name); ?>

                                <br/>
                                Email: <?php echo e($user->email); ?>

                                <br/>
                                Phone Number: <?php echo e($user->mobile); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="panel-heading">
                                <div class="panel-title"><?php echo e($listing->title); ?> Details  (<?php echo e($category->name); ?> - <?php echo e($subcategory->name); ?>)</div>
                            </div>
                            <div class="panel-body  col-md-8">
                                <form method="post" action="<?php echo e(route('admin.updateListing')); ?>">
                                    <?php echo csrf_field(); ?>

                                    <div class="form-group">
                                        <label for="title">Title</label>
                                        <input type="text" name="title" value="<?php echo e($listing->title); ?>" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="Description">Description</label>
                                        <textarea cols="10" rows="10" name="description" class="form-control"><?php echo e($listing->description); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <span class="col-md-6">
                                             <label for="category">Category</label>
                                        <select name="category_id" onchange="get_subcategory()" class="form-control" id="category">
                                            <?php foreach($categories as $cat): ?>
                                                <option value="<?php echo e($cat->id); ?>" <?php if($cat->id == $listing->category_id): ?> selected <?php endif; ?>><?php echo e($cat->name); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        </span>

                                        <span class="col-md-6">
                                             <label for="category">Sub Category</label>
                                        <select name="sub_category_id" class="form-control"id="subcategorylist">
                                            <?php foreach($subcategories as $subcat): ?>
                                                <option value="<?php echo e($subcat->id); ?>" <?php if($subcat->id == $listing->sub_category_id): ?> selected <?php endif; ?>><?php echo e($subcat->name); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        </span>
                                    </div>
                                    <div class="form-group col-md-12" >

                                        <?php if($images != null): ?>
                                            <?php foreach($images as $image): ?>
                                                <div class="col-md-3">
                                                    <img name="images" src="<?php echo e(asset($image_path->value.$image->filename)); ?>" class="thumb" style="margin-bottom: 15px;">
                                                </div>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>

                                    <div class="panel-footer">
                                        <div class="panel-title">
                                            <div class="form-group" style="margin-top: 5px">
                                                Actions: &nbsp;
                                                <input type="checkbox" name="is_active" <?php if($listing->is_active == 1): ?> checked <?php endif; ?>> Active
                                                <input type="checkbox" name="is_featured" <?php if($listing->is_featured == 1): ?> checked <?php endif; ?>> Featured
                                            </div>
                                        </div>

                                        <input type="hidden" value="<?php echo e($listing->id); ?>" name="id">

                                        <input type="submit" class="btn btn-info">

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>


            </div>

        </div>

    </div>
    <!-- ============================================================== -->
    <!-- End Right content here -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/assets/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/assets/datatables/dataTables.bootstrap.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('js/admin/categorySwitch.js')); ?>"></script>


    <script type="text/javascript">
        $(document).ready(function() {
            $('#datatable').dataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>