<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('admin/assets/datatables/jquery.dataTables.min.css" rel="stylesheet')); ?>" type="text/css" />
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
            <!-- ============================================================== -->
    <!-- Start right Content here -->
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <ul>
                        <li class="dropdown" style="list-style: none">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                           <span class="panel-title"><h4>New Content Header
                                                 </h4>
                                               </span>
                            </a>

                        </li>
                    </ul>


                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <form method="post" action="<?php echo e(route('admin.saveNewHeader')); ?>">
                                <?php echo csrf_field(); ?>

                                <div class="row col-md-8">
                                    <div class="form-group">
                                        <label for="title">Title</label>
                                        <input type="text" name="title" class="form-control" required>
                                    </div>

                                    <div class="form-group">
                                        <label for="order">Order</label>
                                        <input type="number" name="order" class="form-control" required>
                                    </div>
                                    <div class="form-group">

                                        <input type="checkbox" name="is_active" > Active
                                    </div>
                                </div>
                                <div class="row col-md-8">
                                    <input type="submit" class="btn btn-info">
                                </div>

                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- ============================================================== -->
    <!-- End Right content here -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/assets/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/assets/datatables/dataTables.bootstrap.js')); ?>"></script>


    <script type="text/javascript">
        $(document).ready(function() {
            $('#datatable').dataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>