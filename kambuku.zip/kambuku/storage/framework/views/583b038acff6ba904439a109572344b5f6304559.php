
<?php $__env->startSection('scripts'); ?>

    <script>

        $(document).ready(function($){
           document.getElementById('selcountry').change(function(){
               alert('changed');
                $.get("<?php echo e(route('cities')); ?>", { option: $(this).val() },

                        function(data) {

                            var cities = $('#selcity');

                            cities.empty();

                            $.each(data, function(key, value) {

                                cities

                                        .append($("<option></option>")

                                                .attr("value",key)

                                                .text(value));
                            });
                        });
            });
        });
    </script>
<?php $__env->stopSection(); ?>