<!--
/**
 * Created by PhpStorm.
 * User: cheza
 * Date: 2/10/16
 * Time: 9:45 PM
 */ -->

<div class="recent_searches"><!--Recent_Searches-->
    <h2>Most Searched</h2>
    <div class="recent-name">
        <ul class="nav nav-pills nav-stacked">
            <li><a href="#"> <span class="pull-right">(50)</span>Golf GTi</a></li>
            <li><a href="#"> <span class="pull-right">(56)</span>Samsung S4</a></li>
            <li><a href="#"> <span class="pull-right">(27)</span>Lumia 1020</a></li>
            <li><a href="#"> <span class="pull-right">(32)</span>Defy Twelve Zero One</a></li>
            <li><a href="#"> <span class="pull-right">(5)</span>PS3 Games</a></li>
            <li><a href="#"> <span class="pull-right">(9)</span>Office Chairs</a></li>
            <li><a href="#"> <span class="pull-right">(4)</span>House for rent</a></li>
        </ul>
    </div>
</div><!--/recent_searches-->