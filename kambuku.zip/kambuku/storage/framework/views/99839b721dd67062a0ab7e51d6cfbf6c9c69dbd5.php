<?php $__env->startSection('title'); ?>
    <?php echo e($subcategory->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('middle_header'); ?>
    <?php echo $__env->make('partials.middle_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_header'); ?>
    <?php echo $__env->make('partials.bottom_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <?php echo $__env->make('partials.breadcrumbs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-sm-3">
                <div class="left-sidebar">
                <?php echo $__env->make('partials.category_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('partials.adverts.sidebar_ad', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('partials.most_searched', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    <div class="col-sm-9 padding-right">
        <div class="features_items"><!--category_items-->
            <h2 class="title text-center"><?php echo e($category->name); ?> - <?php echo e($subcategory->name); ?></h2>
            <?php foreach($listingsArray as $key => $value): ?>
                <div class="col-sm-4">
                    <div class="product-image-wrapper">
                        <div class="single-products">
                            <div class="productinfo text-center">
                                <img src="<?php echo e(asset($image_path->value.$value['image_path'])); ?>" alt="" />
                                <h2><?php echo e(number_format($value['price'], 2)); ?></h2>
                                <p><?php echo e($value['title']); ?></p>
                                <a href="<?php echo e(route('classifieds.show', [$value['id']])); ?>" class="btn btn-default add-to-cart">View Item</a>
                            </div>
                        </div>
                        <div class="choose">
                            <ul class="nav nav-pills nav-justified">
                                <li><a href=""><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
                                <li><a href=""><i class="fa fa-plus-square"></i>Add to compare</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
    </div>
        <div class="col-sm-4">
            <?php echo $listingsArray->appends(['perPage' => $perPage])->links(); ?>

        </div><!--Category_items-->
  </div>
</div></div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>