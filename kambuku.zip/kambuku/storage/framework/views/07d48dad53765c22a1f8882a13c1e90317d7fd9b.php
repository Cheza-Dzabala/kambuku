<?php $__env->startSection('title'); ?>
  Edit <?php echo e($classified->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('middle_header'); ?>
    <?php echo $__env->make('partials.middle_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_header'); ?>
    <?php echo $__env->make('partials.bottom_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <?php echo $__env->make('partials.breadcrumbs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="row">
                <div class="col-sm-3">
                    <div class="left-sidebar">



                    <?php echo $__env->make('partials.adverts.sidebar_ad', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
            <div class="col-sm-9 padding-right">
                <?php echo Form::open(array('url'=>route('classifieds.update', $classified->id),'method'=>'PATCH', 'files'=>true)); ?>

                    <?php echo csrf_field(); ?>

                <h2 class="title text-center">Edit Your <?php echo e($classified->title); ?></H2>

                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">

                    <div class=" col-md-6">
                        <input type="text" name="name" value="<?php echo e($classified->title); ?>" class="form-control" placeholder="Name">
                        <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                     <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
                    <div class=" col-md-6">
                        <input type="number" value="<?php echo e($classified->price); ?>" name="price" min="0" max="10000000" class="form-control" placeholder="Price">
                        <?php if($errors->has('price')): ?>
                            <span class="help-block">
                                         <strong><?php echo e($errors->first('price')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('decription') ? ' has-error' : ''); ?>" style="padding-top: 5%">
                    <div class="col-md-12">
                        <textarea name="description" id="descrption"  class="form-control" rows="8" placeholder="Product Description"><?php echo e($classified->description); ?></textarea>
                        <?php if($errors->has('description')): ?>
                            <span class="help-block">
                                                <strong><?php echo e($errors->first('description')); ?></strong>
                                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-12" style="padding-top: 1.5%">
                    <label>Category</label>
                           <span  class="form-control">
                               <label href="#myModal" style="cursor: pointer;" data-toggle="modal" id="category"><?php echo e($category->name); ?></label>

                               <span class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?> col-md-12">
                               <input type="hidden" name="category" value="<?php echo e($category->id); ?>" id="category_input"/>
                                   <?php if($errors->has('category')): ?>
                                       <span class="help-block">
                                                <strong><?php echo e($errors->first('category')); ?></strong>
                                            </span>
                                   <?php endif; ?>
                               </span>

                                <div class="form-group<?php echo e($errors->has('subcategory') ? ' has-error' : ''); ?> col-md-12">
                                    <input type="hidden" name="subcategory" value="<?php echo e($sub_category->id); ?>" id="subcategory_input"/>
                                    <?php if($errors->has('subcategory')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('subcategory')); ?></strong>
                                            </span>
                                    <?php endif; ?>
                                </div>
                               <label id="subcategory" >:: <?php echo e($sub_category->name); ?></label>
                           </span>
                </div>

                <div class="col-md-12" style="padding-top: 1.5%">
                    <div class="info"><span></span></div>
                    <div class="form-group">
                        <h5>Images (Uploaded <?php echo e($classified_images_count); ?> out of 5)  <small class="text-muted">Select The Images that you want deleted</small></h5>

                        <div class="carousel-inner">
                            <div class="portfolioContainer">
                                <?php if($classified_images_count != 0): ?>
                                <?php $c = 0 ?>
                                    <?php foreach($classified_images as $key => $value): ?>
                                        <img src="<?php echo e(asset($image_path->value.$value['filename'])); ?>" class="thumb-img" width="100px" height="100px" alt="">
                                        <input type="checkbox" value="<?php echo e($value['filename']); ?>" name="check_box_images_<?php echo e($c); ?>">
                                   <?php $c++ ?>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group" style="padding-top: 1.5%">
                        <h5>Image Upload <small class="text-muted">Upload More <?php echo e(5 - $classified_images_count); ?> Images</small></h5>
                        <?php $i = 1; ?>
                        <?php $o = $classified_images_count ?>
                        <?php if($classified_images_count < 5): ?>
                           <?php while($o < 5): ?>
                                <?php echo Form::file( 'file'.$i, ['id'=>'file'.$i]); ?>

                               <?php $i++; $o++ ?>
                            <?php endwhile; ?>
                        <?php else: ?>
                            Your image upload max has been reached, delete some pictures before you upload anymore.
                        <?php endif; ?>
                    </div>

                </div>

                <div  class="col-md-4" style="padding-top: 1.5%">
                    <label>Condition</label>
                    <select name="condition" class="form-control" >
                        <?php foreach($conditions as $key => $value): ?>
                            <?php if($value['id'] == $classified->contition): ?>
                                <option value="<?php echo e($value['id']); ?>" selected><?php echo e($value['name']); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($value['id']); ?>"><?php echo e($value['name']); ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div  class="col-md-4" style="padding-top: 1.5%">
                    <label>Status</label>
                    <select name="is_active" class="form-control" >
                        <option value="1">Active</option>
                        <option value="0">Not Active</option>
                    </select>
                </div>

                <div class="form-group<?php echo e($errors->has('tags') ? ' has-error' : ''); ?> col-md-12" style="padding-top: 1.5%">
                    <input type="text" name="tags" class="form-control" value="<?php echo e($classified->keywords); ?>"  placeholder="tags">
                    <?php if($errors->has('category')): ?>
                        <span class="help-block">
                                                <strong><?php echo e($errors->first('tags')); ?></strong>
                                            </span>
                    <?php endif; ?>
                    <span>Please enter keywords separated buy commas(,). Tags help people find your stuff easier</span>
                </div>
                <div class="form-group col-md-12">
                    <input type="submit" name="submit" class="btn btn-primary pull-right" value="Update">
                </div>
               <?php echo Form::close(); ?>

            </div>
        </div>
        </div>

    </section>
    <?php echo $__env->make('classifieds.category_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/classifieds/create.js')); ?>" ></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>