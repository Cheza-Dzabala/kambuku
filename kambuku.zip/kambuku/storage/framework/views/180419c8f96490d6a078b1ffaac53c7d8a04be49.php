<?php
/**
 * Created by PhpStorm.
 * User: cheza
 * Date: 2/16/16
 * Time: 3:15 PM
 */?>

<template id="cities-template">
    load cities
</template>
