<?php $__env->startSection('middle_header'); ?>
    <?php echo $__env->make('partials.middle_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <section id="form" style="margin-top: 0px; margin-bottom: 0px"><!--form-->
        <div class="container">
            <div class="row">
                <div class="col-sm-4 col-sm-offset-1">
                    <div class="login-form">
                        <h2><?php echo e(Lang::get('auth.enter_password')); ?></h2>
                        <form class="form-horizontal"  method="POST" action="<?php echo e(url('/login')); ?>">
                            <?php echo csrf_field(); ?>


                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">

                                <div class="col-md-6">
                                    <input type="email" name="email"
                                           value="<?php echo e(old('email')); ?>"
                                           placeholder="Email"
                                           style="width: 300px"
                                    >

                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">


                                <div class="col-md-6">
                                    <input type="password"
                                           name="password"
                                           placeholder="Password"
                                           style="width: 300px"
                                    >

                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>

                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6">
                                    <div >
                                     <span>
                                        <input type="checkbox"  class="checkbox" name="remember"> Remember Me
                                    </span>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-12 ">
                                    <div class="col-md-4">
                                        <button type="submit" class="btn btn-primary">
                                          <?php echo e(Lang::get('actions.login')); ?>

                                        </button>
                                    </div>
                                    <div class="col-md-3">
                                      <h3><?php echo e(Lang::get('actions.or')); ?></h3>
                                    </div>
                                    <div class="col-md-4">
                                        <a class="btn btn-primary" href="<?php echo e(url('/register')); ?>">
                                            <?php echo e(Lang::get('actions.register')); ?>

                                        </a>
                                    </div>
                                </div>
                                <a class="btn btn-link" href="<?php echo e(url('/password/reset')); ?>"><?php echo e(Lang::get('auth.forget_password')); ?></a>
                            </div>
                        </form>
                    </div>

            </div>
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>