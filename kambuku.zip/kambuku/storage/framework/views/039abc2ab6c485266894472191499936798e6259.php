<?php $__env->startSection('title'); ?>
    <?php echo e($user_details['name']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('middle_header'); ?>
    <?php echo $__env->make('partials.middle_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_header'); ?>
    <?php echo $__env->make('partials.bottom_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" xmlns="http://www.w3.org/1999/html">
        <?php echo $__env->make('partials.breadcrumbs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-sm-3">
                <div class="left-sidebar">

                <?php echo $__env->make('partials.adverts.sidebar_ad', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div class="col-sm-9">
    <div class="user-container">
        <h2 class="title text-center"><?php echo e($user_details['name']); ?> - Edit Your Profile</h2>
        <div id="w">
            <div id="content" class="clearfix">
                <!--<div id="userphoto"><img src="images/Profile/avatar.png" alt="default avatar"></div>-->
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-3">
                        <div class="text-center">
                            <img src="<?php echo e(asset($user_details['image_path'])); ?>" class="avatar img-circle" alt="avatar">
                            <h2 class="text-center">- OR -</h2>
                            <h6>upload a new profile picture...</h6>
                            <input type="file" name="image" class="upload">
                        </div>
                    </div>

                    <!-- edit form column -->
                    <div class="col-md-9 personal-info">
                        <h2>Personal info <small class="text-muted" style="font-size: small">This is the basic information required</small></h2>
                        <form class="form-horizontal" role="form" method="post" action="<?php echo e(route('profile.save')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label class="col-lg-3 control-label">Full Name:</label>
                                <div class="col-lg-8">
                                    <input class="form-control" type="text" name="name" value="<?php echo e($user_details['name']); ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-lg-3 control-label">Date of Birth:</label>
                                <div class="col-lg-8">
                                    <input type="date" name="date_of_birth" value="<?php echo e($user_details['date_of_birth']); ?>" required>
                                </div>
                            </div>

                          <h2>Contacts <small class="text-muted" style="font-size: small">Your Contacts Are Required Before You Make A Listing</small></h2>
                            <div class="form-group">
                                <label class="col-lg-3 control-label">Mobile:</label>
                                <div class="col-lg-8">
                                    <input class="form-control" type="text" name="mobile" value="<?php echo e($user_details['mobile']); ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-lg-3 control-label">Email:</label>
                                <div class="col-lg-8">
                                    <input class="form-control" type="email" name="email" value="<?php echo e($user_details['email']); ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-lg-3 control-label">Address:</label>
                                <div class="col-lg-8">
                                    <textarea name="address" cols="10" rows="5" class="form-control"><?php echo e($user_details['address']); ?></textarea>
                                </div>
                            </div>

                            <h2>Location <small class="text-muted"  style="font-size: small">You need to add your location for your listings</small></h2>
                            <div class="form-group">
                                <label class="col-md-3 control-label">Country:</label>
                                <div class="col-md-8">
                                    <select name="country" class="form-control">

                                            <option selected>Malawi</option>

                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-md-3 control-label">City:</label>
                                <div class="col-md-8">
                                    <select name="city_id" class="form-control">
                                        <?php foreach($cities as $city): ?>
                                            <option value="<?php echo e($city->id); ?>" <?php if($city->id == $user_details['city_id']): ?> selected <?php endif; ?>><?php echo e($city->name); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <h2>Social <small class="text-muted"  style="font-size: small">Help your clients engage with you</small></h2>

                            <div class="form-group">
                                <label class="col-md-3 control-label">Website:</label>
                                <div class="col-md-8">
                                    <input class="form-control" type="text" name="website" value="<?php echo e($user_details['website']); ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label">Facebook Page:</label>
                                <div class="col-md-8">
                                    <input class="form-control" type="text" name="facebook_page" value="<?php echo e($user_details['facebook_page']); ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label">Twitter:</label>
                                <div class="col-md-8">
                                    <input class="form-control" type="text" name="twitter_handle" value="<?php echo e($user_details['twitter_handle']); ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label">Skype:</label>
                                <div class="col-md-8">
                                    <input class="form-control" type="text" name="skype_id" value="<?php echo e($user_details['skype_id']); ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label">Gender:</label>
                                <div class="col-md-8">
                                    <select name="gender" class="form-control">
                                        <?php if($user_details['gender'] == 'm'): ?>
                                            <option value="m" selected>Male</option>
                                            <option value="f">Female</option>

                                        <?php else: ?>
                                            <option value="f" selected>Female</option>
                                            <option value="m">Male</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-md-3 control-label"></label>
                                <div class="col-md-8">
                                    <input type="submit" class="btn btn-primary" value="Save Changes">

                                    <input type="reset" class="btn btn-info cancel" value="Reset Form">
                                    <br/>
                                    <br/>
                                    <a href="<?php echo e(route('profile')); ?>"><< Back To Profile</a>

                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div><!-- @end  #content -->
        </div><!-- @end  #w -->

    </div><!--/User-Container-->
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>