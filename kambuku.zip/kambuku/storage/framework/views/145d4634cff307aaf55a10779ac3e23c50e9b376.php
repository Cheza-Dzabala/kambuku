<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('admin/assets/datatables/jquery.dataTables.min.css" rel="stylesheet')); ?>" type="text/css" />
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>


            <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <div class="row">

        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                   New Slide
                </div>

                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                           <?php echo Form::open(array('route'=>'admin.addNewSlide','method'=>'POST', 'files'=>true)); ?>

                                <?php echo csrf_field(); ?>

                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>  col-md-8">
                                    <input type="text" class="form-control" name="name" placeholder="Slide Name">

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>


                                <div class="form-group<?php echo e($errors->has('client_name') ? ' has-error' : ''); ?>  col-md-8">
                                    <input type="text" class="form-control" name="client_name" placeholder="Client Name">

                                    <?php if($errors->has('client_name')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('client_name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('client_phoneNumber') ? ' has-error' : ''); ?>  col-md-8">
                                    <input type="text" class="form-control" name="client_phoneNumber" placeholder="Client Phone Number">

                                    <?php if($errors->has('client_phoneNumber')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('client_phoneNumber')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>


                                <div class="form-group<?php echo e($errors->has('header') ? ' has-error' : ''); ?>  col-md-8">
                                    <input type="text" class="form-control" name="header" placeholder="Slide Heading">

                                    <?php if($errors->has('header')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('header')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('sub_header') ? ' has-error' : ''); ?>  col-md-8">
                                    <input type="text" class="form-control" name="sub_header" placeholder="Slide Sub Heading">

                                    <?php if($errors->has('sub_header')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('sub_header')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('web_link') ? ' has-error' : ''); ?>  col-md-8">
                                    <input type="text" class="form-control" name="web_link" placeholder="Web Link">

                                    <?php if($errors->has('web_link')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('web_link')); ?></strong>
                                            </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('facebook_link') ? ' has-error' : ''); ?>  col-md-8">
                                    <input type="text" class="form-control" name="facebook_link" placeholder="Facebook Link">

                                    <?php if($errors->has('facebook_link')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('facebook_link')); ?></strong>
                                            </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('twitter_link') ? ' has-error' : ''); ?>  col-md-8">
                                    <input type="text" class="form-control" name="twitter_link" placeholder="Twitter Link">

                                    <?php if($errors->has('twitter_link')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('twitter_link')); ?></strong>
                                            </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('order') ? ' has-error' : ''); ?>  col-md-5">
                                    <input type="text" class="form-control" name="order" placeholder="Display Order">
                                    <?php if($errors->has('order')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('order')); ?></strong>
                                            </span>
                                    <?php endif; ?>
                                </div>

                            <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?> col-md-8">

                                <textarea name="description" rows="10" class="form-control"></textarea>
                                <?php if($errors->has('description')): ?>
                                    <span class="help-block">
                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                        </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group<?php echo e($errors->has('image_path') ? ' has-error' : ''); ?> col-md-8">

                                    <?php echo Form::label('image_path', 'Upload Your Banner (500KB Max)'); ?>


                                    <?php echo Form::file('image_path', ['id'=>'image_path', 'class'=>'form-control']); ?>


                                    <?php if($errors->has('image_path')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('image_path')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>


                            <div class="form-group<?php echo e($errors->has('is_active') ? ' has-error' : ''); ?>  col-md-8">
                                <select name="is_active" class="form-control">
                                    <option>Select Active Status</option>
                                    <option value="1">Active</option>
                                    <option value="2">Inactive</option>
                                </select>

                                <?php if($errors->has('is_active')): ?>
                                    <span class="help-block">
                                            <strong><?php echo e($errors->first('is_active')); ?></strong>
                                        </span>
                                <?php endif; ?>
                            </div>


                            <div class="form-group col-md-12">
                              <button class="btn btn-info col-md-6">Save</button>
                            </div>




                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div> <!-- End row -->

    <!-- ============================================================== -->
    <!-- End Right content here -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/assets/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/assets/datatables/dataTables.bootstrap.js')); ?>"></script>


    <script type="text/javascript">
        $(document).ready(function() {
            $('#datatable').dataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>