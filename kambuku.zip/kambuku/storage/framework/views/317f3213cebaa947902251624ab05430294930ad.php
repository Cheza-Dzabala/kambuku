<?php $__env->startSection('content'); ?>


        <!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">
            <div class="row">

                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <ul>
                                <li class="dropdown" style="list-style: none">
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                           <span class="panel-title"><h4><?php echo e($catname->name); ?>

                                                   <span class="caret"></span></h4>
                                               </span>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">New Sub Category</a></li>
                                    </ul>
                                </li>
                            </ul>

                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Sub Categoory Name</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <span style="visibility: hidden"><?php echo e($i = 0); ?></span>
                                            <?php foreach($subcategories as $key => $value): ?>
                                                <tr>
                                                    <td><?php echo e($i= $i+1); ?></td>
                                                    <td><?php echo e($value['name']); ?></td>
                                                    <td>
                                                        <i class="fa fa-pencil-square" style="cursor: pointer"></i>&nbsp;
                                                        <i class="fa fa-power-off" style="cursor: pointer"></i>&nbsp;
                                                        <i class="fa fa-trash" style="cursor: pointer"></i>&nbsp;
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div> <!-- End row -->
        </div> <!-- container -->

    </div> <!-- content -->

    <footer class="footer text-right">
        2015 © Dibs Africa Ltd.
    </footer>

</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>