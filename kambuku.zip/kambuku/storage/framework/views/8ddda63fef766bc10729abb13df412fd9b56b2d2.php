<form method="post" action="<?php echo e(('/admin/login')); ?>">
    <?php echo csrf_field(); ?>

    <input type="email" name="email">
    <br/>
    <input type="password" name="password">

    <input type="submit" value="Submit">
</form>