<?php
/**
 * Created by PhpStorm.
 * User: cheza
 * Date: 6/9/16
 * Time: 8:36 PM
 */ ?>

<?php foreach($adDetails as $key => $value): ?>
    <div class="advertside text-center"><!--ads-->
        <img src="<?php echo e($value['images_path']); ?>" alt="" />
    </div><!--/ads-->
<?php endforeach; ?>

