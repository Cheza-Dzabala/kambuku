<?php $__env->startSection('middle_header'); ?>
    <?php echo $__env->make('middle_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bottom_header'); ?>
    <?php echo $__env->make('bottom_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="slider"><!--slider-->
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div id="slider-carousel" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
                        <li data-target="#slider-carousel" data-slide-to="1"></li>
                        <li data-target="#slider-carousel" data-slide-to="2"></li>
                    </ol>

                    <div class="carousel-inner">
                        <div class="item active">
                            <div class="col-sm-6">
                                <h1>Kambuku.com</h1>
                                <h2>Get Your Featured Ad Here</h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                                <button type="button" class="btn btn-default get">Sign Up</button>
                            </div>
                            <div class="col-sm-6">
                                <img src="images/home/girl1.jpg" class="girl img-responsive" alt="" />
                                <img src="images/home/pricing.png"  class="pricing" alt="" />
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-sm-6">
                                <h1>Kambuku.Com</h1>
                                <h2>#1 Classified Ads in Malawi</h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                                <button type="button" class="btn btn-default get">Sign Up</button>
                            </div>
                            <div class="col-sm-6">
                                <img src="images/home/girl2.jpg" class="girl img-responsive" alt="" />
                                <img src="images/home/pricing.png"  class="pricing" alt="" />
                            </div>
                        </div>

                        <div class="item">
                            <div class="col-sm-6">
                                <h1>Kambuku.com</h1>
                                <h2>Post a free Ad</h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                                <button type="button" class="btn btn-default get">Sign Up</button>
                            </div>
                            <div class="col-sm-6">
                                <img src="images/home/girl3.jpg" class="girl img-responsive" alt="" />
                                <img src="images/home/pricing.png" class="pricing" alt="" />
                            </div>
                        </div>

                    </div>

                    <a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
                        <i class="fa fa-angle-left"></i>
                    </a>
                    <a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
                        <i class="fa fa-angle-right"></i>
                    </a>
                </div>

            </div>
        </div>
    </div>
</section><!--/slider-->

<section>
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="left-sidebar">
                    <h2>Category</h2>
                    <div class="panel-group category-products" id="accordian"><!--category-productsr-->
                        <?php $i = 0 ?>
                      <?php foreach($categories as $key => $value): ?>
                       <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                                    <a data-toggle="collapse" data-parent="#accordian" href="#tab_<?php echo $i; ?>">
                                        <span class="badge pull-right"><i class="fa fa-plus"></i></span>
                                            <?php echo e($key); ?>

                                    </a>
                                </h4>
                            </div>
                            <div id="tab_<?php echo $i; ?>" class="panel-collapse collapse">
                                <div class="panel-body">
                                    <ul>
                                        <?php foreach($value as $k => $v): ?>
                                        <li><a href="#"><?php echo e($v['name']); ?></a></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>

                    </div>
                              <?php $i++; ?>
                        <?php endforeach; ?>
                    </div><!--/category-products-->

                    <div class="recent_searches"><!--Recent_Searches-->
                        <h2>Most Searched</h2>
                        <div class="recent-name">
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="#"> <span class="pull-right">(50)</span>Golf GTi</a></li>
                                <li><a href="#"> <span class="pull-right">(56)</span>Samsung S4</a></li>
                                <li><a href="#"> <span class="pull-right">(27)</span>Lumia 1020</a></li>
                                <li><a href="#"> <span class="pull-right">(32)</span>Defy Twelve Zero One</a></li>
                                <li><a href="#"> <span class="pull-right">(5)</span>PS3 Games</a></li>
                                <li><a href="#"> <span class="pull-right">(9)</span>Office Chairs</a></li>
                                <li><a href="#"> <span class="pull-right">(4)</span>House for rent</a></li>
                            </ul>
                        </div>
                    </div><!--/recent_searches-->

                    <div class="price-range"><!--price-range-->
                        <h2>Price Range</h2>
                        <div class="well text-center">
                            <input type="text" class="span2" value="" data-slider-min="0" data-slider-max="600" data-slider-step="5" data-slider-value="[250,450]" id="sl2" ><br />
                            <b class="pull-left">$ 0</b> <b class="pull-right">$ 600</b>
                        </div>
                    </div><!--/price-range-->

                    <div class="advertside text-center"><!--ads-->
                        <img src="images/home/adverise.jpg" alt="" />
                    </div><!--/ads-->

                </div>
            </div>

            <div class="col-sm-9 padding-right">
                <div class="features_items"><!--features_items-->
                    <h2 class="title text-center">Featured Items</h2>
                    <?php foreach($classifieds as $key => $value): ?>
                    <div class="col-sm-4">
                        <div class="product-image-wrapper">
                            <div class="single-products">
                                <div class="productinfo text-center">
                                    <img src="<?php echo e($value['image_path']); ?>" alt="" />
                                    <h2>MK <?php echo e($value['price']); ?></h2>

                                    <p><?php echo e($value['title']); ?></p>
                                    <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>View Item</a>
                                </div>
                                <div class="product-overlay">
                                    <div class="overlay-content">

                                        <p>  <?php echo e($value['description']); ?> </p>
                                        <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>View Item</a>
                                    </div>
                                </div>
                            </div>
                            <div class="choose">
                                <ul class="nav nav-pills nav-justified">
                                    <li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
                                    <li><a href="#"><i class="fa fa-plus-square"></i>Add to compare</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                     <?php endforeach; ?>


                </div><!--features_items-->

                <div class="category-tab"><!--category-tab-->
                    <div class="col-sm-12">
                        <ul class="nav nav-tabs">
                            <?php $i = 0; $active = 0; $activated = ''; ?>
                    <!--
                    $i is a counter to track tabs and assigned panes,
                    $active check to see what tab should be active,
                    $activated checks to see which tab has been activated and sets the appropriate class in the view pane
                    -->
                            <?php foreach($tabs as $key => $value): ?>
                                <li <?php if($active == 0): ?> class="active" <?php $activated = $i?> <?php endif; ?> >
                                    <a href="#<?php echo e($i); ?>" data-toggle="tab" name="<?php echo e($activated); ?>"><?php echo e($key); ?></a>
                                </li>
                                <?php $active++; $i++ ?>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <div class="tab-content">
                        <?php $i = 0; $verify_active = '' ?>
                        <?php foreach($tabs as $key => $value): ?>
                                <?php $verify_active = $i ?>
                                <div <?php if($verify_active == $activated): ?> class="tab-pane fade active in" <?php else: ?> class="tab-pane fade in" <?php endif; ?> id="<?php echo e($i); ?>" name="<?php echo e($verify_active); ?>" >
                            <?php foreach($value as $k => $v): ?>
                                    <div class="col-sm-3">
                                        <div class="product-image-wrapper">
                                            <div class="single-products">
                                                <div class="productinfo text-center">
                                                    <img src="<?php echo e($v['image_path']); ?>" alt="<?php echo e($v['title']); ?>" />
                                                    <h2><?php echo e($v['price']); ?></h2>
                                                    <p><?php echo e($v['title']); ?></p>
                                                    <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>View Item</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            <?php endforeach; ?>
                                </div>
                                <?php $i++; $verify_active++ ?>
                        <?php endforeach; ?>
                    </div>
                </div><!--/category-tab-->


                <!--Recommended Items <div class="recommended_items">
                    <h2 class="title text-center">recommended items</h2>

                    <div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="item active">
                                <div class="col-sm-4">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="images/home/recommend1.jpg" alt="" />
                                                <h2>MK281</h2>
                                                <p>Easy Polo Black Edition</p>
                                                <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>View Item</a>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="images/home/recommend2.jpg" alt="" />
                                                <h2>MK281</h2>
                                                <p>Easy Polo Black Edition</p>
                                                <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>View Item</a>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="images/home/recommend3.jpg" alt="" />
                                                <h2>MK281</h2>
                                                <p>Easy Polo Black Edition</p>
                                                <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>View Item</a>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-sm-4">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="images/home/recommend1.jpg" alt="" />
                                                <h2>MK281</h2>
                                                <p>Easy Polo Black Edition</p>
                                                <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>View Item</a>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="images/home/recommend2.jpg" alt="" />
                                                <h2>MK281</h2>
                                                <p>Easy Polo Black Edition</p>
                                                <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>View Item</a>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="images/home/recommend3.jpg" alt="" />
                                                <h2>MK281</h2>
                                                <p>Easy Polo Black Edition</p>
                                                <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>View Item</a>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                         <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
                            <i class="fa fa-angle-left"></i>
                          </a>
                          <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
                            <i class="fa fa-angle-right"></i>
                          </a>
                    </div>
                </div><!--/recommended_items-->

            </div>
        </div>
    </div>
</section>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>