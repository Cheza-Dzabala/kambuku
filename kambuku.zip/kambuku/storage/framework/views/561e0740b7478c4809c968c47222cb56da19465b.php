<form action="<?php echo e('admin/register'); ?>" method="post">
    <?php echo csrf_field(); ?>

    <input name="name"  placeholder="name" type="text">
    <input name="password" placeholder="password" type="password">
    <input name="screenname" placeholder="screenname" type="text">
    <input name="email" placeholder="email" type="email">
    <button type="submit">Register</button>
</form>
