<?php $__env->startSection('title'); ?>
    <?php echo e($user_details['name']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('middle_header'); ?>
    <?php echo $__env->make('partials.middle_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_header'); ?>
    <?php echo $__env->make('partials.bottom_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('partials.breadcrumbs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-sm-3">
                <div class="left-sidebar">
                <?php echo $__env->make('partials.adverts.sidebar_ad', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('partials.adverts.sidebar_ad', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div class="col-sm-9">
            <div class="user-container">
                <h2 class="title text-center">Your Profile Summary</h2>
                <div id="w">
                    <div id="content" class="clearfix">
                        <div id="userphoto" class="pull-right"><img src="<?php echo e(asset($user_details['image_path'])); ?>" alt="default avatar" class="img-circle"></div>
                        <h2><?php echo e($user_details['name']); ?>  <small class="text-muted" style="font-size: small"><a href="<?php echo e(route('profile.edit')); ?>">Edit Account Information</a>
                            </small> </h2>

                        <div id="userdetails" class="user-details">
                            <p><span>Date Of Birth: </span><?php echo e($user_details['date_of_birth']); ?></p>
                            <p><span>Address: </span><?php echo e($user_details['address']); ?></p>
                            <p><span>Email: </span> <?php echo e($user_details['email']); ?></p>
                            <p><span>Phone: </span><?php echo e($user_details['mobile']); ?></p>
                            <div style="color: white">

                                    <button class="btn btn-facebook">
                                        <i class="fa fa-facebook fa-2x"></i> <small><?php echo e($user_details->facebook_page); ?></small>
                                    </button>
                                    <button class="btn btn-twitter">
                                        <i class="fa fa-twitter fa-2x"></i> <small><?php echo e($user_details->twitter_handle); ?></small>
                                    </button>
                                    <button class="btn btn-skype">
                                        <i class="fa fa-skype fa-2x"></i><small><?php echo e($user_details->skype_id); ?></small>
                                    </button>

                            </div>
                        </div>
                    <?php echo $__env->make('partials.Account.listings', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    </div><!-- @end  #content -->
                </div><!-- @end  #w -->

            </div><!--/User-Container-->
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/user/accountManagement.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>