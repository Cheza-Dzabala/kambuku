<?php if(isset($empty)): ?>
    <div class="table-responsive userad_info">
        <table class="table table-condensed">
            <thead>
            <tr class="userad_menu">
         <td><center>No Listings To Show</center></td>
            </tr>
            </thead>
        </table>
    </div>
    <?php else: ?>
<div class="table-responsive userad_info">
    <table class="table table-condensed">
        <thead>
        <tr class="userad_menu">

            <td class="image">Item</td>
            <td class="description"></td>
            <td class="price">Price</td>
            <td class="quantity">Active</td>
            <td class="viewa">Views</td>
            <td class="viewa">Action</td>
        </tr>
        </thead>
        <tbody>

        <?php foreach($listings as $key => $value): ?>
        <tr >
            <td class="userad_product" >
                <a href=""><img src="<?php echo e(asset($image_path->value.$value['image_path'])); ?>" alt="Antique Vase" height="100" width=""></a>
            </td>
            <td class="userad_description" style="padding-left: 10%; width: 40%">
                <h4><a href=""><?php echo e($value['title']); ?></a></h4>
                <p
                   style=" overflow: hidden;
                   width: 90%;

                                                   text-overflow: ellipsis;
                                                   display: -webkit-box;
                                                   -webkit-box-orient: vertical;
                                                   -webkit-line-clamp: 1; /* number of lines to show */
                                                   line-height: 25px;        /* fallback */
                                                    max-height: 25px; "
                ><?php echo e($value['description']); ?></p>
            </td>
            <td class="userad_price">
                <p><?php echo e(number_format($value['price'], 2)); ?></p>
            </td>
            <td class="userad_quantity">
                <p>
                    <span  id="activeStatus_<?php echo e($value['id']); ?>">
                    <?php if( $value['is_active'] == '1' ): ?>
                       <span style="color: darkgreen">Active </span>
                        <?php else: ?>
                        Inactive
                     <?php endif; ?>
                    </span>
                </p>
            </td>
            <td class="cuserad_total">
                <p class="userad_views"><?php echo e($value['view_count']); ?></p>
            </td>
            <td class="userad_delete" style="display: inline">
                <a class="userad_quantity_delete"  href="<?php echo e(route('edit.product', [$value['id']])); ?>"><i class="fa fa-pencil"></i></a>
                <span id="activeButton_<?php echo e($value['id']); ?>">
                     <?php if($value['is_active']=='1'): ?>
                        <a class="userad_quantity_delete" onclick="deactivate('<?php echo e($value['id']); ?>')"><i class="fa fa-power-off"></i></a>
                    <?php else: ?>
                        <a class="userad_quantity_delete"  onclick="activate('<?php echo e($value['id']); ?>')"><i class="fa fa-check"></i></a>
                    <?php endif; ?>
                </span>

                <a class="userad_quantity_delete" href="<?php echo e(route('listing.delete', [$value['id']])); ?>"><i class="fa fa-times"></i></a>
            </td>


        </tr>
            <?php endforeach; ?>
        </tbody>

    </table>
    <?php echo $listings->appends(['perPage' => $perPage])->links(); ?>

</div>
    <?php endif; ?>