<div class="left-sidebar">
        <h2>Refine</h2>
        <form>

            <div style="margin-bottom: 3%;" class="form-group">
                <input type="number" style="width: 45%" placeholder="min value" name="min_value"/>
                <span style="width: 10%"> - </span>
                <input type="number" style="width: 45%" placeholder="max price" name="max_value"/>
            </div>

        </form>


