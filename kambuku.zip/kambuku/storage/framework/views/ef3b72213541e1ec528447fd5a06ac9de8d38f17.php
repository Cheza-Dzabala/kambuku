<?php $__env->startSection('title'); ?>
    Create
<?php $__env->stopSection(); ?>
<?php $__env->startSection('middle_header'); ?>
    <?php echo $__env->make('partials.middle_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_header'); ?>
    <?php echo $__env->make('partials.bottom_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <?php echo $__env->make('partials.breadcrumbs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="row">
                <div class="col-sm-3">
                    <div class="left-sidebar">
                    <?php echo $__env->make('partials.category_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php echo $__env->make('partials.most_searched', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php echo $__env->make('partials.adverts.sidebar_ad', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                </div>
                <div class="col-sm-9 padding-right">
                    <h2 class="title text-center">Post an Ad</H2>
                    <?php echo Form::open(array('url'=>'classifieds','method'=>'POST', 'files'=>true)); ?>

                        <?php echo csrf_field(); ?>

                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">

                            <div class=" col-md-6">
                            <input type="text" name="name" class="form-control" placeholder="Name" required>
                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                     <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
                            <div class=" col-md-6">
                            <input type="number" name="price" min="0" max="500000000" class="form-control" placeholder="Price" required>
                                <?php if($errors->has('price')): ?>
                                    <span class="help-block">
                                         <strong><?php echo e($errors->first('price')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('decription') ? ' has-error' : ''); ?>" style="padding-top: 5%">
                                <div class="col-md-12">
                                <textarea name="description" id="descrption"  class="form-control" rows="8" placeholder="Product Description" required></textarea>
                                    <?php if($errors->has('description')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('description')); ?></strong>
                                            </span>
                                    <?php endif; ?>
                                </div>
                        </div>

                        <div class="col-md-12" style="padding-top: 1.5%">
                            <label>Category</label>
                           <span  class="form-control">
                               <label href="#myModal" style="cursor: pointer;" data-toggle="modal" id="category">Category</label>

                               <span class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?> col-md-12">
                               <input type="hidden" name="category" value="" id="category_input"/>
                                   <?php if($errors->has('category')): ?>
                                       <span class="help-block">
                                                <strong><?php echo e($errors->first('category')); ?></strong>
                                            </span>
                                   <?php endif; ?>
                               </span>

                                <div class="form-group<?php echo e($errors->has('subcategory') ? ' has-error' : ''); ?> col-md-12">
                               <input type="hidden" name="subcategory" value="" id="subcategory_input"/>
                                    <?php if($errors->has('subcategory')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('subcategory')); ?></strong>
                                            </span>
                                    <?php endif; ?>
                                </div>
                               <label id="subcategory" ></label>
                           </span>
                        </div>

                        <div class="col-md-12" style="padding-top: 1.5%">
                            <div class="info"><span></span></div>
                            <div class="form-group">
                                <?php echo Form::label('image', 'Select Your Pictures (5MB Max/per Image)'); ?>


                                <?php echo Form::file('file1', ['id'=>'file1', 'class' => 'form-control']); ?>

                                <?php echo Form::file('file2', ['id'=>'file2', 'class' => 'form-control']); ?>

                                <?php echo Form::file('file3', ['id'=>'file3', 'class' => 'form-control']); ?>

                                <?php echo Form::file('file4', ['id'=>'file4', 'class' => 'form-control']); ?>

                                <?php echo Form::file('file5', ['id'=>'file5', 'class' => 'form-control']); ?>

                            </div>

                        </div>

                    <div  class="col-md-4" style="padding-top: 1.5%">
                        <label>Condition</label>
                        <select name="condition" class="form-control" >
                            <?php foreach($condition as $key => $value): ?>
                                <option value="<?php echo e($value['id']); ?>"><?php echo e($value['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div  class="col-md-4" style="padding-top: 1.5%">
                        <label>Status</label>
                        <select name="is_active" class="form-control" >
                            <option value="1">Active</option>
                            <option value="0">Not Active</option>
                        </select>
                    </div>

                        <div class="form-group<?php echo e($errors->has('tags') ? ' has-error' : ''); ?> col-md-12" style="padding-top: 1.5%">
                            <input type="text" name="tags" class="form-control"  placeholder="tags" required>
                            <?php if($errors->has('category')): ?>
                                <span class="help-block">
                                                <strong><?php echo e($errors->first('tags')); ?></strong>
                                            </span>
                            <?php endif; ?>
                            <span>Please enter keywords separated buy commas(,). Tags help people find your stuff easier</span>
                        </div>
                        <div class="form-group col-md-12">
                            <input type="submit" name="submit" class="btn btn-primary pull-right" value="Submit">
                        </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>

    </section>
    <?php echo $__env->make('classifieds.category_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/classifieds/create.js')); ?>" ></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>