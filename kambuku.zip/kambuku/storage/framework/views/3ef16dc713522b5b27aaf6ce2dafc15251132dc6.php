<div class="header-middle"><!--header-middle-->
    <div class="container">
        <div class="row">
            <div class="col-sm-4 col-lg-6">
                <div class="logo pull-left">
                    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('images/home/logo.png')); ?>" alt="" width="80px" height="auto"/></a>
                </div>
                <div class="btn-group pull-right">
                    <?php if(Session::has('inactive')): ?>
                        <div class="alert alert-warning alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(Session::get('inactive')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(Session::has('savedProfile')): ?>
                        <div class="alert alert-success alert-dismissable col-md-12">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(Session::get('savedProfile')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(Session::has('EditedListing')): ?>
                        <div class="alert alert-success alert-dismissable col-md-12">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(Session::get('EditedListing')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(Session::has('listing_failed')): ?>
                        <div class="alert alert-danger alert-dismissable col-md-12">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(Session::get('listing_failed')); ?>

                        </div>
                    <?php endif; ?>


                    <?php if(Session::has('savedListing')): ?>
                        <div class="alert alert-success alert-dismissable col-md-12">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(Session::get('savedListing')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(Session::has('comment')): ?>
                        <div class="alert alert-success alert-dismissable col-md-12">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(Session::get('comment')); ?>

                        </div>
                    <?php endif; ?>


                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-success alert-dismissable col-md-12">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(Session::get('message')); ?>

                        </div>
                    <?php endif; ?>



                </div>
            </div>
            <div class="col-sm-8 col-lg-6">
                <div class="shop-menu pull-right">
                    <ul class="nav navbar-nav">
                        <?php if(Auth::check()): ?>
                        <li><a href="<?php echo e(route('messages')); ?>"><i class="fa fa-envelope"></i> My Messages</a></li>
                        <li><a href="<?php echo e(route('profile')); ?>"><i class="fa fa-user"></i> My Account</a></li>
                        <?php endif; ?>
                        <li><a href="<?php echo e(route('classifieds.create')); ?>"><i class="fa fa-star"></i> <?php echo e(Lang::get('actions.post_ad')); ?></a></li>
                       <?php if(Auth::check()): ?>
                            <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-lock"></i>Logout</a></li>
                       <?php else: ?>
                            <li><a href="<?php echo e(url('/login')); ?>"><i class="fa fa-lock"></i> <?php echo e(Lang::get('actions.login')); ?></a></li>
                            <li><a href="<?php echo e(url('/register')); ?>"><i class="fa fa-lock"></i> <?php echo e(Lang::get('actions.register')); ?></a></li>
                       <?php endif; ?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</div><!--/header-middle-->
	