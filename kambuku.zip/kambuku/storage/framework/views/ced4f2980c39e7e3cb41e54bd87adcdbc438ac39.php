;
<?php $__env->startSection('title'); ?>
        Dashboard::Kambuku
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->


            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">Dashboard !</h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="#">kambuku Admin</a></li>
                        <li class="active">Dashboard</li>
                    </ol>
                </div>
            </div>

            <?php echo $__env->make('admin.partials.dashboard.widgets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>