<?php
/**
 * Created by PhpStorm.
 * User: cheza
 * Date: 2/10/16
 * Time: 8:10 PM
 */?>
<div class="left-sidebar">
    <h2>Category</h2>
    <div class="panel-group category-products" id="accordian"><!--category-productsr-->
        <?php $i = 0 ?>
        <?php foreach($categories as $key => $value): ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordian" href="#tab_<?php echo $i; ?>">
                            <span class="badge pull-right"><i class="fa fa-plus"></i></span>
                            <?php echo e($key); ?>

                        </a>
                    </h4>
                </div>
                <div id="tab_<?php echo $i; ?>" class="panel-collapse collapse">
                    <div class="panel-body">
                        <ul>
                            <?php foreach($value as $k => $v): ?>
                                <li><a href="#"><?php echo e($v['name']); ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>

            </div>
            <?php $i++; ?>
        <?php endforeach; ?>
    </div>
