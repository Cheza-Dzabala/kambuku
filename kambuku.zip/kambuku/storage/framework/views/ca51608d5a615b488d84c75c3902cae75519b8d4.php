<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('middle_header'); ?>
    <?php echo $__env->make('partials.middle_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_header'); ?>
    <?php echo $__env->make('partials.bottom_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section>
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="left-sidebar">
               <?php echo $__env->make('partials.category_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('partials.adverts.homePageStandardBlocks', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <br/>
                    <?php echo $__env->make('partials.most_searched', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>

            <div class="col-sm-9 padding-right">

                <div class="features_items"><!--features_items-->
                    <h2 class="title text-center">Featured Items</h2>
                    <?php foreach($classifieds as $key => $value): ?>
                    <div class="col-sm-4">
                        <div class="product-image-wrapper">
                            <div class="single-products">
                                <div class="productinfo text-center">
                                    <img src="<?php echo e($image_path->value.$value['image_path']); ?>" alt="" />
                                    <h2>MK <?php echo e(number_format($value['price'], 2)); ?></h2>

                                    <p><?php echo e($value['title']); ?></p>
                                    <a href="#" class="btn btn-default add-to-cart">View Item</a>
                                </div>
                                <div class="product-overlay">
                                    <div class="overlay-content">

                                        <p>  <?php echo e($value['description']); ?> </p>
                                        <a href="<?php echo e(route('classifieds.show', [$value['id']])); ?>" class="btn btn-default add-to-cart">View Item</a>
                                    </div>
                                </div>
                            </div>
                            <div class="choose">
                                <ul class="nav nav-pills nav-justified">
                                    <li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
                                    <li><a href="#"><i class="fa fa-plus-square"></i>Add to compare</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                     <?php endforeach; ?>
                </div><!--features_items-->

                <div class="features_items"><!--features_items-->
                    <h2 class="title text-center">Latest Items</h2>
                    <?php foreach($latest as $key => $value): ?>
                        <div class="col-sm-4">
                            <div class="product-image-wrapper">
                                <div class="single-products">
                                    <div class="productinfo text-center">
                                        <img src="<?php echo e($image_path->value.$value['image_path']); ?>" alt="" />
                                        <h2>MK <?php echo e(number_format($value['price'], 2)); ?></h2>

                                        <p><?php echo e($value['title']); ?></p>
                                        <a href="#" class="btn btn-default add-to-cart">View Item</a>
                                    </div>
                                    <div class="product-overlay">
                                        <div class="overlay-content">

                                            <p>  <?php echo e($value['description']); ?> </p>
                                            <a href="<?php echo e(route('classifieds.show', [$value['id']])); ?>" class="btn btn-default add-to-cart">View Item</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="choose">
                                    <ul class="nav nav-pills nav-justified">
                                        <li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
                                        <li><a href="#"><i class="fa fa-plus-square"></i>Add to compare</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php echo $__env->make('partials.adverts.homeStripAds', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="category-tab col-sm-12 col-md-12 col-lg-12"><!--category-tab-->
                    <div class="col-sm-12">
                        <ul class="nav nav-tabs">
                            <?php $i = 0; $active = 0; $activated = ''; ?>
                    <!--
                    $i is a counter to track tabs and assigned panes,
                    $active check to see what tab should be active,
                    $activated checks to see which tab has been activated and sets the appropriate class in the view pane
                    -->
                            <?php foreach($tabs as $key => $value): ?>
                                <li <?php if($active == 0): ?> class="active" <?php $activated = $i?> <?php endif; ?> >
                                    <a href="#<?php echo e($i); ?>" data-toggle="tab" name="<?php echo e($activated); ?>"><?php echo e($key); ?></a>
                                </li>
                                <?php $active++; $i++ ?>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <div class="tab-content">


                        <?php $i = 0; $verify_active = '' ?>
                        <?php foreach($tabs as $key => $value): ?>
                                <?php $verify_active = $i ?>
                                <div <?php if($verify_active == $activated): ?> class="tab-pane fade active in" <?php else: ?> class="tab-pane fade in" <?php endif; ?> id="<?php echo e($i); ?>" name="<?php echo e($verify_active); ?>" >

                                    <?php foreach($value as $k => $v): ?>
                                            <div class="col-sm-4">
                                                <div class="product-image-wrapper">
                                                    <div class="single-products">
                                                        <div class="productinfo text-center">
                                                            <img src="<?php echo e($image_path->value.$v['image_path']); ?>" alt="<?php echo e($v['title']); ?>" />
                                                            <h2>Mk <?php echo e(number_format($v['price'],2)); ?></h2>
                                                            <p><?php echo e($v['title']); ?></p>
                                                            <a href="<?php echo e(route('classifieds.show', [$v['id']])); ?>"class="btn btn-default add-to-cart">View Item</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                    <?php endforeach; ?>

                                </div>
                                <?php $i++; $verify_active++ ?>
                        <?php endforeach; ?>

                    </div>
                </div><!--/category-tab-->
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>