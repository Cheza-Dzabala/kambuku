
<div class="header-middle"><!--header-middle-->
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <div class="logo pull-left">
                    <a href="index.html"><img src="images/home/logo.png" alt="" /></a>
                </div><br/>
              <?php if(Session::has('country')): ?>


                <?php else: ?>
                    <?php if(isset($countries)): ?>
                    <select id="selcountry" name="selcountry" class=" pull-left" style="width: 100px;">

                        <?php foreach($countries as $key => $value): ?>
                            <option id="<?php echo e($value['id']); ?>"><?php echo e($value['name']); ?></option>
                        <?php endforeach; ?>

                    </select>

                    <select id="selcity" name="selcity" class="pull-right" style="width: 123px;">
                        <option ></option>
                    </select>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="col-sm-8">
                <div class="shop-menu pull-right">
                    <ul class="nav navbar-nav">
                        <?php if(Auth::check()): ?>
                        <li><a href="#"><i class="fa fa-user"></i> Account</a></li>
                        <?php endif; ?>
                        <li><a href=""><i class="fa fa-star"></i> Post an Ad</a></li>

                        <?php if(Auth::check()): ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <i class="fa fa-angle-down"></i>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
                                </ul>
                            </li>
                            <?php else: ?>
                            <li><a href="<?php echo e(route('login')); ?>"><i class="fa fa-lock"></i> Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>"><i class="fa fa-lock"></i> Register</a></li>
                        <?php endif; ?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</div><!--/header-middle-->

<?php echo $__env->make('scripts.country_city', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>