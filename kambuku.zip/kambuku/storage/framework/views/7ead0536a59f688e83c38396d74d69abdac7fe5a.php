<div class="col-sm-12">
    <?php if(isset($review)): ?>
    <?php foreach($review as $key => $value): ?>
    <ul>
        <li><a><i class="fa fa-user"></i><?php echo e($value['name']); ?></a></li>
        <li><a><i class="fa fa-calendar-o"></i><?php echo e($value['created_at']); ?></a></li>
    </ul>
    <p><?php echo e($value['comment']); ?></p>
    <?php endforeach; ?>
    <?php endif; ?>
    <p><b>Write Your Review</b></p>
   <?php if(Auth::check()): ?>
    <form action="<?php echo e(route('new_review')); ?>" method="POST">
        <?php echo csrf_field(); ?>

										<span>
											<input type="text" name="name" value="<?php echo e(Auth::user()->name); ?>"/>
											<input type="email" name="email" placeholder="Email Address" value="<?php echo e(Auth::user()->email); ?>"/>
										</span>
        <textarea name="comment" ></textarea>
        <input type="hidden" name="classified_id" value="<?php echo e($classified_details->id); ?>">
        <b>Rating: </b> <img src="<?php echo e(asset('images/product-details/rating.png')); ?>" alt="" />

            <?php if(Auth::user()['id'] != $user_info->id): ?>
                <button type="submit" class="btn btn-default pull-right">
                    Submit
                </button>
            <?php endif; ?>

    </form>
       <?php else: ?>
      <p>You need to be logged in to write reviews</p>
   <?php endif; ?>
   <script type="text/javascript">
       document.getElementById('count').innerHTML = "<?php echo e($comment_count); ?>";
   </script>
</div>