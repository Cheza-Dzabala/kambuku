<div class="tab-pane fade" id="morefrom" >
    <?php foreach($more as $key => $value): ?>
        <div class="col-sm-3">
            <div class="product-image-wrapper">
                <div class="single-products">
                    <div class="productinfo text-center">
                        <img src="<?php echo e(asset($image_path->value.$value['image_path'])); ?>" height="150px" width="50px" alt="" />
                        <h2><?php echo e(number_format($value['price'], 2)); ?></h2>
                        <p><?php echo e($value['title']); ?></p>
                        <a href="<?php echo e(route('classifieds.show', [$value['id']])); ?>" type="button" class="btn btn-default add-to-cart">View Item</a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>