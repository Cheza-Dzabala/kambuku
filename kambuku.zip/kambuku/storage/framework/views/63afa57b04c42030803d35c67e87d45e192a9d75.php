<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('middle_header'); ?>
    <?php echo $__env->make('partials.middle_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_header'); ?>
    <?php echo $__env->make('partials.bottom_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="row">
            <div class="col-sm-3">
                <div class="left-sidebar">
                    <?php echo $__env->make('partials.search.refine', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('partials.adverts.sidebar_ad', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                 </div>
            </div>
        </div>
        <div class="col-sm-9">
            <div class="user-container">
                <h2 class="title text-center">Searching - Results For <?php echo e($search_term); ?></h2>
                <div id="w">
                    <div class="table-responsive search_info">
                        <?php if(isset($empty)): ?>
                            <table class="table table-condensed">
                                <thead >
                                    <tr class="search_results">
                                        <th class="description">No Results To Display</th>
                                    </tr>
                                </thead>
                           </table>
                        <?php else: ?>
                        <table class="table table-condensed">
                            <thead >
                            <tr class="search_results">
                                <th class="image">Image</th>
                                <th class="description">Description</th>
                                <th class="price">Price</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($listingsArray as $key => $value): ?>
                            <tr>
                                <td class="search_product" style="margin-right: 5px">
                                    <a href="<?php echo e(route('classifieds.show', [$value['id']])); ?>"><img src="<?php echo e(asset($image_path->value.$value['image_path'])); ?>" width="140px" height="140px"></a>
                                </td>
                                <td class="search_description">
                                    <h4><a href="<?php echo e(route('classifieds.show', [$value['id']])); ?>" style="color: #0f0f0f"><?php echo e($value['title']); ?></a></h4>
                                    <p style="white-space: nowrap;text-overflow:ellipsis; max-width: 70ch; overflow: hidden;"><?php echo e($value['description']); ?></p>
                                </td>
                                <td class="search_price">
                                    <p>MK <?php echo e(number_format($value['price'], 2)); ?></p>
                                </td>

                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php echo $listingsArray->appends(['perPage' => $perPage, 'search_term' => $search_term])->links(); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>