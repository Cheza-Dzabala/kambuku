<?php $__env->startSection('title'); ?>
    <?php echo e($classified_details->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('middle_header'); ?>
    <?php echo $__env->make('partials.middle_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_header'); ?>
    <?php echo $__env->make('partials.bottom_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
    <?php echo $__env->make('partials.breadcrumbs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-sm-3">
            <div class="left-sidebar">
           <?php echo $__env->make('partials.category_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials.most_searched', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials.adverts.sidebar_ad', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>

        <div class="col-sm-9 padding-right">
            <div class="product-details"><!--product-details-->

                <div class="col-sm-5">
                    <div class="view-product">
                        <img src="<?php echo e(asset($image_path->value.$classified_details->image_path)); ?>" alt="" />

                    </div>
                    <div id="other-images" class="carousel slide" data-ride="carousel">

                        <!-- Wrapper for slides THUMBNAILS -->
                            <?php if(isset($thumbnails)): ?>
                            <div class="carousel-inner">
                                <div class="portfolioContainer">
                                    <div class="item active">
                                        <?php $set = 0?>
                                    <?php foreach($thumbnails as $key => $value ): ?>
                                    <a href="<?php echo e(asset($image_path->value.$images[$key]['filename'])); ?>" title="<?php echo e($classified_details->title); ?>" class="image-popup">
                                        <img src="<?php echo e(asset($thumb_image_path->value.$value['filename'])); ?>" class="thumb-img" alt="">
                                    </a>
                                    <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        <!-- Controls -->
                        <!--
                        <a class="left item-control" href="#similar-product" data-slide="prev">
                            <i class="fa fa-angle-left"></i>
                        </a>
                        <a class="right item-control" href="#similar-product" data-slide="next">
                            <i class="fa fa-angle-right"></i>
                        </a> -->
                    </div>
                    <Span><b>Tags:</b> <?php echo e($classified_details->keywords); ?></span>
                    <br/>
                    <button type="button" class="btn btn-danger ">
                        Flag as Inappropriate
                    </button>
                </div>

                <div class="col-sm-7">
                    <div class="product-information"><!--/product-information-->
                        <?php if($difference == 'Today'): ?>
                            <img src="<?php echo e(asset('images/product-details/new.jpg')); ?>" class="newarrival" alt="" />
                        <?php elseif($difference < 2 && $difference != '1 week ago' && $difference != '1 month ago' && $difference != '1 year ago'): ?>

                            <img src="<?php echo e(asset('images/product-details/new.jpg')); ?>" class="newarrival" alt="" />
                        <?php endif; ?>
                        <h2><?php echo e($classified_details->title); ?></h2>
                        <p><?php echo e($classified_details->description); ?></p>
                         <small class="col-lg-12 col-md-12 col-sm-12">Posted: <?php echo e($difference); ?>

                         </small>
                        <!--<img src="images/product-details/rating.png" alt="" />-->
								<span>
									<span>MK <?php echo e(number_format($classified_details->price, 2)); ?></span>
                                    <?php if(Auth::user()['id'] != $user_info->id): ?>
									    <a href="#reviews"><button type="button" class="btn btn-default cart">
                                            Review Classified
                                        </button></a>
                                    <?php endif; ?>
								</span>
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()['id'] != $user_info->id): ?>
                               <p><b>Seller Info : </b><?php echo e($user_info->name); ?>

                                   <a href="#new_messageModal" data-toggle="modal">
                                       <button type="button" class="btn btn-default cart">
                                           Contact This User
                                       </button>
                                   </a>
                               </p>
                            <?php endif; ?>
                        <?php endif; ?>
                        <p><b>Email Address : </b><?php echo e($user_info->email); ?></p>
                        <p><b>Location : </b><?php echo e($location->name); ?></p>
                        <p><b>Phone #:</b> <?php if($user_info->mobile == ''): ?>None Listed <?php else: ?> <?php echo e($user_info->mobile); ?><?php endif; ?></p>
                        <p><b>Condition:</b> <?php echo e($condition->name); ?></p>
                        <p><b>Views:</b><?php echo e($classified_details->view_count); ?></p>

                        <h2 style="padding-top: 2px">Find This User On</h2>
                            <p><b>Facebook : </b><?php echo e($user_info->facebook_page); ?></p>
                            <p><b>Twitter : </b><?php echo e($user_info->twitter_handle); ?></p>
                            <p><b>Skype : </b><?php echo e($user_info->skype_id); ?></p>
                        <?php echo $__env->make('partials.product_page.safety', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div><!--/product-information-->
                </div>
            </div><!--/product-details-->

            <div class="category-tab shop-details-tab"><!--category-tab-->
                <div class="col-sm-12">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#reviews" data-toggle="tab">Reviews (<span id="count"></span>)</a></li>
                        <li><a href="#morefrom" data-toggle="tab">More From</a></li>
                        <li><a href="#related" data-toggle="tab">related</a></li>
                    </ul>
                </div>
                <div class="tab-content">
                    <?php echo $__env->make('partials.product_page.more_from', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('partials.product_page.related_products', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="tab-pane fade active in" id="reviews" >
                        <?php echo $__env->make('partials.product_page.reviews', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                 </div>
               </div><!--/category-tab-->



            </div>
        </div>
    <!-- Go to www.addthis.com/dashboard to customize your tools -->

    </div>
    <?php echo $__env->make('messaging.new_message_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>
    <script type="text/javascript">
        $(window).load(function(){
            var $container = $('.portfolioContainer');
            $container.isotope({
                filter: '*',
                animationOptions: {
                    duration: 750,
                    easing: 'linear',
                    queue: false
                }
            });

            $('.portfolioFilter a').click(function(){
                $('.portfolioFilter .current').removeClass('current');
                $(this).addClass('current');

                var selector = $(this).attr('data-filter');
                $container.isotope({
                    filter: selector,
                    animationOptions: {
                        duration: 750,
                        easing: 'linear',
                        queue: false
                    }
                });
                return false;
            });
        });
        $(document).ready(function() {
            $('.image-popup').magnificPopup({
                type: 'image',
                closeOnContentClick: true,
                mainClass: 'mfp-fade',
                gallery: {
                    enabled: true,
                    navigateByImgClick: true,
                    preload: [0,1] // Will preload 0 - before current, and 1 after the current image
                }
            });
        });
    </script>
    <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-56f10c41fbec7d18"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>