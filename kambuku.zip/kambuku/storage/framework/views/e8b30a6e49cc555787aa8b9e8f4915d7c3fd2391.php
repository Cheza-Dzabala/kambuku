<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('admin/assets/datatables/jquery.dataTables.min.css" rel="stylesheet')); ?>" type="text/css" />
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>


            <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <div class="row">

        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <ul>
                        <li class="dropdown" style="list-style: none">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                           <span class="panel-title"><h4>Slides
                                                   <span class="caret"></span></h4>
                                               </span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo e(route('admin.newHomesliderconfig')); ?>">New Slide</a></li>
                            </ul>
                        </li>
                    </ul>

                </div>

                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="table-responsive">
                                <table id="datatable" class="table table-striped table-bordered">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Slider Name</th>
                                        <th>Client</th>
                                        <th>Client Phone Number</th>
                                        <th>Header</th>
                                        <th>Active Status</th>
                                        <th>Display Order</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach($slides as $slide): ?>
                                        <tr>
                                            <td></td>
                                            <td>
                                                <?php echo e($slide->name); ?>

                                            </td>
                                            <td>
                                               <?php echo e($slide->client_name); ?>

                                            </td>
                                            <td>
                                              <?php echo e($slide->client_phoneNumber); ?>

                                            </td>
                                            <td>
                                                <?php echo e($slide->header); ?>

                                            </td>
                                            <td>
                                                <?php echo e($slide->is_active); ?>

                                            </td>
                                            <td>
                                               <?php echo e($slide->order); ?>

                                            </td>
                                            <td>
                                                <i class="fa fa-pencil-square fa-lg" style="cursor: pointer; color: lightskyblue"></i>&nbsp;
                                                <i class="fa fa-trash fa-lg" style="cursor: pointer; color: red"></i>&nbsp;
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div> <!-- End row -->

    <!-- ============================================================== -->
    <!-- End Right content here -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('admin/assets/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('admin/assets/datatables/dataTables.bootstrap.js')); ?>"></script>


    <script type="text/javascript">
        $(document).ready(function() {
            $('#datatable').dataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>