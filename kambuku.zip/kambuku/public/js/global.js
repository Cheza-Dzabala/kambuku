/**
 * Created by cheza on 3/14/16.
 */

//Messages Page

current_conversation = "";
auth_user_id = "";
