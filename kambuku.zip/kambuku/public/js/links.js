/**
 * Created by cheza on 3/1/16.
 */

var main_link = 'http://192.168.1.108:8000/';


var main_host = 'http://192.168.1.108';

var port = ':8000/';