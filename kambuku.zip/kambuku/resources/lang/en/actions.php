<?php
/**
 * Created by PhpStorm.
 * User: cheza
 * Date: 6/28/16
 * Time: 12:12 PM
 */

return [
    'post_ad' => 'Post An Ad',
    'login' => 'Login',
    'register' => 'Register',
    'or' => 'OR'
];
