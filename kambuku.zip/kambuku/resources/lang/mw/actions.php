<?php
/**
 * Created by PhpStorm.
 * User: cheza
 * Date: 6/28/16
 * Time: 12:12 PM
 */

return [
    'post_ad' => 'Positani Malonda',
    'login' => 'Lowani',
    'logintText' => 'Lowani Muwakaunti',
    'register' => 'Lembetsani',
    'or' => 'kapena'
];
