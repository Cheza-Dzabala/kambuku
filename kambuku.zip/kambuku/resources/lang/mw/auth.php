<?php
/**
 * Created by PhpStorm.
 * User: cheza
 * Date: 6/30/16
 * Time: 10:54 AM
 */


return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'mawu anu achinsisi sakugukrwirizana ndi malekodi athu.',
    'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
    'enter_password' => 'Chonde Lowetsani Email yanu ndi mawu anu achinsisi m\'musimu',
    'forget_password' => 'Kodi mwaiwala mawu anu achinsisi?'


];
